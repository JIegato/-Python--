from django.db import models


class Picture(models.Model):
    description = models.CharField(max_length=500)
    file = models.ImageField(upload_to='Media/',null=True)
